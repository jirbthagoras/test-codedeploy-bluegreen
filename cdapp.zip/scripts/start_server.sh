#!/bin/bash
sudo systemctl start nginx
sudo systemctl enable nginx
echo "server jalan"